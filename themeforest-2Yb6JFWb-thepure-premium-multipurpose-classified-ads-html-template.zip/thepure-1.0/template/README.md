# ThePure - Responsive Bootstrap Classified Ads HTML Template

Hello and Thank You For Your Purchase!
**************************************

Support available online on product page.

Cheers

CodinBit